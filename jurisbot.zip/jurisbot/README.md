# JurisBot

## Pasos para publicar en Vercel

1. Creá una cuenta gratis en https://vercel.com
2. Instalá Vercel CLI: `npm i -g vercel`
3. Desde la carpeta del proyecto: `vercel`
4. Cuando te pida, configurá las variables de entorno:
   - SERP_KEY = 04f6391ad11b8f0cb8e4474b6b80c84d1252aca407f01fbd8f72b3bb1d6dbdef
   - ANTHROPIC_KEY = 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
5. Listo — Vercel te da una URL del tipo jurisbot.vercel.app
6. Conectá tu dominio jurisbot.com.ar desde el panel de Vercel

## Estructura
jurisbot/
├── index.html       ← landing + buscador
├── api/
│   ├── search.js    ← proxy a SerpAPI
│   └── claude.js    ← proxy a Anthropic
└── vercel.json      ← configuración
